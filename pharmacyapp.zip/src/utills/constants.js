export const assetsPrefix = process.env.NEXT_PUBLIC_ASSETS_PREFIX
  ? process.env.NEXT_PUBLIC_ASSETS_PREFIX
  : "";