/* Components */
import HomePage from "@/src/components/HomePage";

export default function IndexPage() {
  return <HomePage />;
}

export const metadata = {
  title: "PharmacyShop Online",
};
