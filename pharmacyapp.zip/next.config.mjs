/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Add basePath

  distDir: 'out',
}

export default nextConfig
